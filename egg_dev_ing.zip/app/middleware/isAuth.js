 
module.exports=option=>{
	return async function isAuth(ctx, next){
		console.log('我是中间件');
    
  
    const userToken = ctx.get('token');
    if(userToken) {
      const user = await ctx.service.user.getUser(userToken);
      if(user) {
        ctx.session.user = user;
        console.log(ctx.session.user)
        await next();//放行
      } else {
        const res = {
          code: -99,
          data: {
            url: ctx.helper.logoutUrl(),
          },
          msg: '请重新登陆!',
        }
        ctx.body = res;
      }
    } else {
      const res = {
        code: -99,
        data: {
          url: ctx.helper.logoutUrl(),
        },
        msg: '请重新登陆!',
      }
      ctx.body = res;
    }	
	}
}