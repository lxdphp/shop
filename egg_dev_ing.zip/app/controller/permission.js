const Controller = require('egg').Controller;

const { v4: uuidv4 } = require('uuid');

class PermissionController extends Controller {
  

}

module.exports = PermissionController;