const Service = require('egg').Service;

const headers = {
	"Authorization": 'Bearer MTY1MTEyNjYyNC41NTI2MzY5Jjg1MWUxOWUyNWZjYmU2ZTAzNTdhMjZhNDI0MjQ5NmY2OTVhYmZmN2FmYWJjZDc5MjAzNGU1MWE4ZDg5ZjU1NWU=',
	"Content-Type": "application/json",
}

class ShotgunService extends Service {

	async getAxcessToken() {
		const { ctx } = this;

		const data = {
			grant_type: 'password',
			username: 'lingxiao',
			password: 'ling0310?!',
		}
    const url = `${this.config.shotgunHost}/api/v1/auth/access_token`;

    try {
      const res = await ctx.curl(url, {
        dataType: 'json',
        data,
        method: 'POST',
      });
      console.log('service shotgun getAxcessToken res', res.data);
      return res.data;
    } catch (error) {
      console.log('service shotgun getAxcessToken error: ', error);
      return [];
    }
		
		
	}

	async getProjectList() {
		const { ctx } = this;
		const resAccesstoken = await ctx.service.bd.shotgun.getAxcessToken();
		const token = resAccesstoken.access_token;
		const headers = {
			Authorization: 'Bearer ' + token,
			'Accept': 'application/json',
		}
		const fields = '?fields=name'
		const filter = '&filter[sg_production_or_not]=商业项目'
		const url2 = `${this.config.shotgunHost}/api/v1/entity/Project/${fields}${filter}`;
		console.log('url2', url2)
		const res2 = await ctx.curl(url2, {
			dataType: 'json',
			headers,
		});
		//console.log('222222222222 getUsers res2', res2.data);
		//console.log(333333333, tree_data);
		const list = res2.data.data;
		const resq = [];
		list.map(item => {
			resq.push({
				id: item.id,
				name: item.attributes.name,
			})
		})
		return resq;
		this.ctx.helper.success(ctx, 1, '成功', resq);
	}

	async getStepList() {
		const { ctx } = this;
		const resAccesstoken = await ctx.service.bd.shotgun.getAxcessToken();
		const token = resAccesstoken.access_token;
		const headers = {
			Authorization: 'Bearer ' + token,
			'Accept': 'application/json',
		}
		const fields = '?fields=*'
		const filter = '&filter[entity_type]=Shot,Asset'
		const url2 = `${this.config.shotgunHost}/api/v1/entity/Step/${fields}${filter}`;
	  
    try {
      const res2 = await ctx.curl(url2, {
        dataType: 'json',
        headers,
      });

      const list = res2.data.data;
    
      const resq = [];
      list.map(item => {
        resq.push({
          //id: item.id,
          value: item.attributes.code,
          label: item.attributes.code,
          disabled: false,
          color: ctx.helper.setRgbTo16(`rgb(${item.attributes.color})`),
        })
      })

		  return resq;
    } catch (error) {
      return [];
    }
		
		
	}

}
module.exports = ShotgunService;

